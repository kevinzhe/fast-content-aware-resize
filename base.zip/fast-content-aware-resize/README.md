# Fast content-aware resize Base Implementation

To build the binary, run

`make` 

This creates binary `base` inside the \bin folder

The binary takes in 3 arguments - input file, output file and number of seams to remove.

For example,

`base beach_1080p.jpg new_beach_1080p.jpg 3`

We have provided sample pictures and a script in the optimized implementation to run benchmarking tests with the binaries `base` and `car` (optimized).